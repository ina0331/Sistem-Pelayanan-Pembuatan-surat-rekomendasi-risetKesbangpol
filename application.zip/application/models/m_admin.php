<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class m_admin extends CI_Model {

	function login($username,$password){
		return $this->db->query("SELECT * FROM admin WHERE username = '$username' AND password='$password' ");
	}

 function get_data($table){
    return $this->db->get($table);
  }

 function get_data2($table,$id_admin){
    $this->db->select('nama_admin');
    $this->db->where('id_admin',$id_admin);
    return $this->db->get($table);
  }

function edit_data($where,$table){
    return $this->db->get_where($table,$where);
    
  }

  function insert_data($data,$table){
    $this->db->insert($table,$data);
  }

  function update_data($table,$data,$where){
    $this->db->update($table,$data,$where);
  }

  function delete_data($where,$table){
    $this->db->where($where);
    $this->db->delete($table);
  }

  function get_data_pembayaran($kd_pembayaran=''){
    $this->db->select('*');
    $this->db->from('siswa');
    $this->db->join('pembayaran','pembayaran.id_siswa = siswa.id_siswa','inner');
    if ($kd_pembayaran!=''){
      $this->db->where('pembayaran.kd_pembayaran',$kd_pembayaran);
    }
    return $this->db->get();

    // $this->db->query("select * from siswa inner join pembayaran on pembayaran.id_siswa = siswa.id_siswa ");
  }

} 

?>