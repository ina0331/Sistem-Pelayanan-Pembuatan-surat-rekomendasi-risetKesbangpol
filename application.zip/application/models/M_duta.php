<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_duta extends CI_Model {
    
    public function prosesInsert($table,$data){
   		$insert = $this->db->insert($table,$data);
   		return $insert;
    }

    public function get_data($table){
        $data = $this->db->get($table);
        return $data->result_array();
    }

    public function tambah($table,$data){
        $tambah = $this->db->insert($table,$data);
        return $tambah;
    }


    public function dataedit($table,$id){
        $this->db->where('id_brg',$id);
        $data = $this->db->get($table);
        return $data->row();
    }
    public function hapus($table,$id){
        $this->db->where('id_test',$id);
        $hapus = $this->db->delete($table);
        return $hapus;
    }
    public function hapus1($table,$id){
        $this->db->where('id_peneliti',$id);
        $hapus1 = $this->db->delete($table);
        return $hapus1;
    }
    public function hapus2($table,$id){
        $this->db->where('id_test',$id);
        $hapus2 = $this->db->delete($table);
        return $hapus2;
    }
   
    function login($username, $password) {
        $periksa = $this->db->get_where('admin', array('username' => $username, 'password' => md5($password)));
        if($periksa->num_rows()>0){
        	return 1;
        }else{
        	return 0;
        }
    }
}