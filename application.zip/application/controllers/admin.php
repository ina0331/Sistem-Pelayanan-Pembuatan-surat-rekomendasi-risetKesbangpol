<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class admin extends CI_Controller {

 public function index(){
 	if($this->session->userdata('id_admin') == ""){
			redirect(base_url('admin/login'));
		}else{
			$this->load->view('admin/home');
			$this->load->view('admin/content');

  } 

  } 	  
 	  public function login(){
 	  	if($this->session->userdata('id_admin') != ""){
			redirect(base_url('admin'));
		}
 	  	$data['judul'] = "Login";   
 	  	$this->load->view('admin/login',$data); 
 	  	
 	  }

 	  public function login_proses(){
 	  	$username = $this->input->post('username');
 	  	$password = md5($this->input->post('password'));

 	  	// num_rows();jumlah isi data table
 	  	// row_array(); bongkar satuan data table
 	  	// result(); bongkar total table

 	  	$cek_login = $this->m_admin->login($username,$password)->num_rows();

 	  	

 	  	// echo $cek_login;

 	  	if ($cek_login==0){
 	  		redirect(base_url('admin/login'));
 	  	}else{
 	  		$data_login = $this->m_admin->login($username,$password)->row_array();
 	  		$id_admin = $data_login['id_admin'];

 	  		$this->session->set_userdata('id_admin',$id_admin);
	 	  	$data_session = $this->m_admin->login($username,$password)->row_array();
	 	  	// $this->session->set_userdata($id_session);
	 	  	redirect('admin');
 	  	}
 	  	
 	  	}
 	function logout(){
 		$this->session->sess_destroy();
 		redirect(base_url('admin'));
 	}

 	public function data_user(){
 		$data['data_user'] = $this->m_admin->get_data('user')->result();
 		$this->load->view('admin/home');
 		$this->load->view('admin/v_data_user',$data);
 	} 


 	public function bukutamu(){
 		$data['bukutamu'] = $this->m_admin->get_data('buku_tamu')->result();
 		$this->load->view('admin/home');
 		$this->load->view('admin/v_bukutamu',$data);
 	} 

 	  function tambah_data_user(){
      $this->load->view('admin/home');
      $this->load->view('admin/v_tambah_data_user');
    }

    function tambah_data_user_act(){
      $nama_lengkap = $this->input->post('nama_lengkap');
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));
      $email = $this->input->post('email');
      $no_telp = $this->input->post('no_telp');
     
      $this->form_validation->set_rules('nama_lengkap','Nama','required');
      $this->form_validation->set_rules('username','Username','required');
      $this->form_validation->set_rules('password','Password','required');
      $this->form_validation->set_rules('email','Elamat','required');
      $this->form_validation->set_rules('no_telp','Nomor Telepon','required');
      if($this->form_validation->run() != false){
          $data = array(
            'nama_lengkap' => $nama_lengkap,
            'username' => $username,
            'password' => $password,
            'email' => $email,
            'no_telp' => $no_telp,
          );
           $this->m_admin->insert_data($data,'user');
            $this->session->set_flashdata('info','*Berhasil ditambahkan');
 
          redirect(base_url().'admin/data_user');
        }else{
          $this->load->view('admin/home');
          $this->load->view('admin/v_data_user');
          
        }
      }

        function edit_user($id){
        $where = array('id_user' =>$id);
        $data['data_user'] = $this->db->query("select * from user where id_user='$id'")->result();

        $this->load->view('admin/home');
        $this->load->view('admin/edit_user',$data);
      }

      function update_user(){
      $id = $this->input->post('id');
      $nama_lengkap = $this->input->post('nama_lengkap');
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));
      $email = $this->input->post('email');
      $no_telp = $this->input->post('no_telp');
      
      $this->form_validation->set_rules('nama_lengkap','Nama','required');
      $this->form_validation->set_rules('username','Username','required');
      $this->form_validation->set_rules('password','Password','required');
      $this->form_validation->set_rules('email','Email','required');
      $this->form_validation->set_rules('no_telp','Nomor Telepon','required');
     
        if($this->form_validation->run() != false){
            $where = array('id_user' => $id);
            $data = array(
            'nama_lengkap' => $nama_lengkap,
            'username' => $username,
            'password' => $password,
            'email' => $email,
            'no_telp' => $no_telp,
             
          );

            $this->m_admin->update_data('user',$data,$where);
             $this->session->set_flashdata('info','*Berhasil diupdate');
            redirect(base_url().'admin/data_user');
          } else{
              $where = array('id_user' =>$id);
              $data['data_user'] = $this->db->query("select * from user where id_user='$id'")->result();
              $this->load->view('admin/home');
              $this->load->view('admin/edit_user',$data);
          }
      }

      function hapus_user($id){
        $where = array('id_user' => $id);
        $this->m_admin->delete_data($where,'user');
         $this->session->set_flashdata('info','*Berhasil dihapus');
        redirect(base_url().'admin/data_user');
      }

         function hapus_bukutamu($id){
        $where = array('id_bukutamu' => $id);
        $this->m_admin->delete_data($where,'buku_tamu');
         $this->session->set_flashdata('info','*Berhasil dihapus');
        redirect(base_url().'admin/bukutamu');
      }

     function data_pengajuan(){
 		$data['data_pengajuan'] = $this->m_admin->get_data('peneliti')->result();
 		$this->load->view('admin/home');
 		$this->load->view('admin/data_pengajuan',$data);
 	} 
      function hapus_pengajuan($id){
        $where = array('id_peneliti' => $id);
        $this->m_admin->delete_data($where,'peneliti');
        $this->session->set_flashdata('info','*Berhasil dihapus');
        redirect(base_url().'admin/data_pengajuan');
      }


      public function data_admin(){
 		$data['data_admin'] = $this->m_admin->get_data('admin')->result();
 		$this->load->view('admin/home');
 		$this->load->view('admin/v_data_admin',$data);
 	} 

 	  function tambah_data_admin(){
      $this->load->view('admin/home');
      $this->load->view('admin/v_tambah_data_admin');
    }

    function tambah_data_admin_act(){
      $nama_lengkap = $this->input->post('nama_lengkap');
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));
      $email = $this->input->post('email');
      $no_telp = $this->input->post('no_telp');
     
      $this->form_validation->set_rules('nama_lengkap','Nama','required');
      $this->form_validation->set_rules('username','Username','required');
      $this->form_validation->set_rules('password','Password','required');
      $this->form_validation->set_rules('email','Elamat','required');
      $this->form_validation->set_rules('no_telp','Nomor Telepon','required');
      if($this->form_validation->run() != false){
          $data = array(
            'nama_lengkap' => $nama_lengkap,
            'username' => $username,
            'password' => $password,
            'email' => $email,
            'no_telp' => $no_telp,
          );
           $this->m_admin->insert_data($data,'admin');
            $this->session->set_flashdata('info','*Berhasil ditambahkan');
 
          redirect(base_url().'admin/data_admin');
        }else{
          $this->load->view('admin/home');
          $this->load->view('admin/v_data_admin');
          
        }
      }

        function edit_admin($id){
        $where = array('id_admin' =>$id);
        $data['data_admin'] = $this->db->query("select * from admin where id_admin='$id'")->result();

        $this->load->view('admin/home');
        $this->load->view('admin/edit_admin',$data);
      }

      function update_admin(){
      $id = $this->input->post('id');
      $nama_lengkap = $this->input->post('nama_lengkap');
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));
      $email = $this->input->post('email');
      $no_telp = $this->input->post('no_telp');
      
      $this->form_validation->set_rules('nama_lengkap','Nama','required');
      $this->form_validation->set_rules('username','Username','required');
      $this->form_validation->set_rules('password','Password','required');
      $this->form_validation->set_rules('email','Email','required');
      $this->form_validation->set_rules('no_telp','Nomor Telepon','required');
     
        if($this->form_validation->run() != false){
            $where = array('id_admin' => $id);
            $data = array(
            'nama_lengkap' => $nama_lengkap,
            'username' => $username,
            'password' => $password,
            'email' => $email,
            'no_telp' => $no_telp,
             
          );

            $this->m_admin->update_data('admin',$data,$where);
             $this->session->set_flashdata('info','*Berhasil diupdate');
            redirect(base_url().'admin/data_admin');
          } else{
              $where = array('id_admin' =>$id);
              $data['data_admin'] = $this->db->query("select * from admin where id_admin='$id'")->result();
              $this->load->view('admin/home');
              $this->load->view('admin/edit_admin',$data);
          }
      }

      function hapus_admin($id){
        $where = array('id_admin' => $id);
        $this->m_admin->delete_data($where,'admin');
         $this->session->set_flashdata('info','*Berhasil dihapus');
        redirect(base_url().'admin/data_admin');
      }
 
      public function cetak_laporan(){

    $this->load->view('admin/home');
    $this->load->view('admin/cetak_laporan');
  }  

   public function data_diri(){
    if($this->session->userdata('id_admin') == ""){
        redirect(base_url('admin/login'));
      }else{
      $data['admin'] = $this->m_admin->edit_data(array('id_admin' => $this->session->userdata('id_admin')),'admin')->result();

      $d=$this->m_admin->edit_data(array('admin.id_admin' => $this->session->userdata('id_admin')),'admin')->num_rows();
      $this->load->view('admin/home');
      $this->load->view('admin/data_diri',$data);
    }
  }  

     function laporan_print_pengajuan(){
          $data['pengajuan'] = $this->m_admin->get_data('peneliti')->result();
          $this->load->view('admin/laporan_print_pengajuan',$data);
        }

     function laporan_print_user(){
          $data['user'] = $this->m_admin->get_data('user')->result();
          $this->load->view('admin/laporan_print_user',$data);
        } 



 }