<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kesbang extends CI_Controller {
function __construct(){
	parent::__construct();
	require_once APPPATH."third_party/dompdf/dompdf_config.inc.php";
	
}

	public function index()
	{
		$this->load->view('index');
	}
	public function dashboard()
	{
		$this->load->view('admin/dashboard');
	}
	
	public function pendaftaran()
	{
		$this->load->view('pendaftaran');
	}

  public function print_surat()
  {
  
    $this->load->view('cetak_bukti',$data);
  }
	public function gallery()
	{
		$this->load->view('gallery');
	}
	public function tentang()
	{
		$this->load->view('tentang');
	}

	public function kontak()
	{
		$this->load->view('kontak');
	}

   function buku_tamu(){

      $nama_lengkap = $this->input->post('nama_lengkap');
      $email = $this->input->post('email');
      $subjek = $this->input->post('subjek');
      $pesan = $this->input->post('pesan');
      $this->form_validation->set_rules('nama_lengkap','Nama','required');
      $this->form_validation->set_rules('email','Elamat','required');
      $this->form_validation->set_rules('subjek','subjek','required');
      $this->form_validation->set_rules('pesan','Pesan','required');
      
      if($this->form_validation->run() != false){
          $data = array(
            'nama_lengkap' => $nama_lengkap,
            'subjek' => $subjek,
            'pesan' => $pesan,
            'email' => $email,
             
          );
          $this->m_user->insert_data($data,'buku_tamu');
          $this->session->set_flashdata('info','*Berhasil diposting');
     redirect(base_url('kesbang/kontak'));
        }else{
          
          $this->load->view('Kesbang/kontak');
          $this->session->set_flashdata('info','*Gagal diposting');
        }
      }

  function laporan_print_surat(){
      
      if($this->session->userdata('id_peneliti') == ""){
        redirect(base_url());
      }else{    
      $data['peneliti'] = $this->m_user->edit_data(array('id_peneliti' => $this->session->userdata('id_peneliti')),'peneliti')->result();

      $d=$this->m_user->edit_data(array('peneliti.id_peneliti' => $this->session->userdata('id_peneliti')),'peneliti')->num_rows();

      $this->load->view('cetak_bukti2',$data);
    }
  }
	public function register_akun()
	{
		$this->load->view('v_registerakun');
	}
	function register_akun_act(){

      $data = array('nama_lengkap' => $this->input->post('nama_lengkap',true),
      	            'username' =>  $this->input->post('username',true),
                    'password' => md5($this->input->post('password',true)),
                    'email' => $this->input->post('email',true),
                    'no_telp' => $this->input->post('no_telp',true));
	$insert = $this->M_duta->prosesInsert('user',$data);	
	if($insert > 0){
	 $this->load->view('login2', $data);
	}else{
		echo ' gagal';
		}
			
	} 

	 public function login_user(){
    if($this->session->userdata('id_user') != ""){
      redirect(base_url('kesbang'));
    }
      $data['judul'] = "Login";   
      $this->load->view('login2',$data);  
  }    

public function login_proses(){
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));

      // num_rows();jumlah isi data table 
      // row_array(); bongkar satuan data table
      // result(); bongkar total table

      $cek_login = $this->m_user->login($username,$password)->num_rows();

       

      // echo $cek_login;

      if ($cek_login==0){
        redirect(base_url('Kesbang/login_user'));
      }else{
        $data_login = $this->m_user->login($username,$password)->row_array();
        $id_user = $data_login['id_user'];

        $this->session->set_userdata('id_user',$id_user);

        $data_session = $this->m_user->login($username,$password)->row_array();
        // $this->session->set_userdata($id_session);
        redirect('Kesbang');
      }

    }


    function logout(){
    $this->session->sess_destroy();
    redirect(base_url('kesbang'));
  }

	public function login()
	{
		$this->load->view('admin/login');
	}
	public function a_peneliti()
	{
			$this->data['pen'] = $this->M_duta->get_data('peneliti');
	$this->load->view('admin/a_peneliti', $this->data);
	}

	public function delete1($id){
		$hapus1 = $this->M_duta->hapus1('peneliti',$id);
		if($hapus1 > 0){
			redirect('kesbang/a_peneliti');
		}else{
			echo 'gagal';
		}
	}
	function cetak(){
          $dompdf = new Dompdf();
          $data = array(
          	"nama" => "nama_lengkap",
          	"tempat_lahir" => "tempat_lahir",
          	"tgl_lahir" => "tgl_lahir",
          	"identitas" => "identitas",
          	"no_identitas" => "no_identitas",
          	"univ" => "univ",
          	"program_studi" => "program_studi",
          	"fakultas" => "fakultas",
          	"matkul" => "matkul",
          	"p_tinggi" => "p_tinggi",
          	"agama" => "agama",
          	"pekerjaan" => "pekerjaan",
          	"no_telp" => "no_telp",
          	"alamat" => "alamat",
          	"email" => "email",
          	"tema" => "tema",
          	"akhir_tgl" => "akhir_tgl",
          	"awal_tgl" => "awal_tgl",
          	"tgl" => "tgl",
          );

          $html = $this->load->view('cetak_bukti',$data,true);

          $dompdf->load_html($html);

          $dompdf->set_paper('A4','landscape');
          
          $dompdf->render();
          
          $pdf = $dompdf->output();
          
          $dompdf->stream('cetak_bukti', array("attachement" => false));
        }

  public function upload(){ 
    if($this->session->userdata('id_user') == ""){
        redirect(base_url('kesbang/login_user'));
      }else{
    $this->load->view('pendaftaran');
      $nama_lengkap = $this->input->post('nama_lengkap');
      $tempat_lahir = $this->input->post('tempat_lahir');
      $tgl_lahir = $this->input->post('tgl_lahir');
      $identitas = $this->input->post('identitas');
      $jenis_kelamin = $this->input->post('jenis_kelamin');
      $univ = $this->input->post('univ');
      $program_studi = $this->input->post('program_studi');
      $matkul = $this->input->post('matkul');
      $fakultas = $this->input->post('fakultas');
      $pendidikan = $this->input->post('pendidikan');
      $agama = $this->input->post('agama');
      $alamat = $this->input->post('alamat');
      $no_telp = $this->input->post('no_telp');
      $email = $this->input->post('email');
      $tema = $this->input->post('tema');
      $no_surat = $this->input->post('no_surat');
      $awal_tgl = $this->input->post('awal_tgl');
      $akhir_tgl = $this->input->post('akhir_tgl');
      $tgl = $this->input->post('tgl');
      $this->form_validation->set_rules('nama_lengkap','Nama','required');
       $this->form_validation->set_rules('tempat_lahir','tempat lahir','required');
      $this->form_validation->set_rules('tgl_lahir','Tanggal lahir','required');
      $this->form_validation->set_rules('identitas','NIM','required');
      $this->form_validation->set_rules('univ','Universitas','required');
      $this->form_validation->set_rules('program_studi','Program studi','required');
      $this->form_validation->set_rules('matkul','matkul','required');
      $this->form_validation->set_rules('fakultas','Fakultas','required');
      $this->form_validation->set_rules('pendidikan','Pendidikan','required');
      $this->form_validation->set_rules('agama','Agama','required');
      $this->form_validation->set_rules('alamat','Alamat','required');
      $this->form_validation->set_rules('tema','Tema','required');
      $this->form_validation->set_rules('no_telp','Nomor Telepon','required');
      $this->form_validation->set_rules('email','email','required');
      $this->form_validation->set_rules('tgl','Tanggal Acara','required');
            if($this->form_validation->run() != false){

        $config['upload_path'] = './assets/images/berkas/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '2048';
        $config['file_name'] = 'gambar'.time();

        $this->load->library('upload',$config);

        if($this->upload->do_upload('ktp')){
          $image = $this->upload->data();

        if($this->upload->do_upload('surat')){
          $image2 = $this->upload->data();

          $data = array(
            'ktp' => $image['file_name'],
            'surat' => $image2['file_name'],
            'id_user' => $this->session->userdata('id_user'),
            'nama_lengkap' => $nama_lengkap,
            'tempat_lahir' => $tempat_lahir,
            'tgl_lahir' => $tgl_lahir,
            'identitas' => $identitas,
            'univ' => $univ,
            'program_studi' => $program_studi,
            'matkul' => $matkul,
            'fakultas' => $fakultas,
            'pendidikan' => $pendidikan,
            'agama' => $agama,
            'alamat' => $alamat,
            'no_telp' => $no_telp,
            'email' => $email,
            'jenis_kelamin' => $jenis_kelamin,
            'no_surat' => $no_surat,
            'tema' => $tema,
            'awal_tgl' => $awal_tgl,
            'akhir_tgl' => $akhir_tgl,
            'tgl' => $tgl, 
          );
      
          $this->m_user->insert_data($data,'peneliti');
          $this->session->set_flashdata('info','*Berhasil diupload');
      $this->load->view('cetak_bukti');
        }else{

          $this->load->view('Kesbang');
           $this->session->set_flashdata('info','*Tidak dapat diupload');
        }
      }
  }
  } 
}
}