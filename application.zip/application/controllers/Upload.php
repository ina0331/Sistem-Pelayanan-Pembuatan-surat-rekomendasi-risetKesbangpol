<?php
defined('BASEPATH') or exit ('no direct script access allowed');
class Upload extends CI_Controller {

        public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form','url'));
        }

        public function index()
        {
        if($this->session->userdata('id_user') == ""){
        redirect(base_url('kesbang/login_user'));
      }else{
         $this->load->view('pendaftaran');
      $id_user = $this->session->userdata('id');
      $query          = $this->m_user->getUser($id_user);
      $data['id_user']   = $id_user;
      $data['id_user']    = $this->input->post('id_user');

      $nama_lengkap = $this->input->post('nama_lengkap');
      $tempat_lahir = $this->input->post('tempat_lahir');
      $tgl_lahir = $this->input->post('tgl_lahir');
      $identitas = $this->input->post('identitas');
      $jenis_kelamin = $this->input->post('jenis_kelamin');
      $univ = $this->input->post('univ');
      $program_studi = $this->input->post('program_studi');
      $matkul = $this->input->post('matkul');
      $fakultas = $this->input->post('fakultas');
      $pendidikan = $this->input->post('pendidikan');
      $agama = $this->input->post('agama');
      $alamat = $this->input->post('alamat');
      $no_telp = $this->input->post('no_telp');
      $email = $this->input->post('email');
      $tema = $this->input->post('tema');
      $no_surat = $this->input->post('no_surat');
      $awal_tgl = $this->input->post('awal_tgl');
      $akhir_tgl = $this->input->post('akhir_tgl');
      $tgl = $this->input->post('tgl');
      $this->form_validation->set_rules('nama_lengkap','Nama','required');
      $this->form_validation->set_rules('tempat_lahir','tempat lahir','required');
      $this->form_validation->set_rules('tgl_lahir','Tanggal lahir','required');
      $this->form_validation->set_rules('identitas','NIM','required');
      $this->form_validation->set_rules('univ','Universitas','required');
      $this->form_validation->set_rules('program_studi','Program studi','required');
      $this->form_validation->set_rules('matkul','matkul','required');
      $this->form_validation->set_rules('fakultas','Fakultas','required');
      $this->form_validation->set_rules('pendidikan','Pendidikan','required');
      $this->form_validation->set_rules('agama','Agama','required');
      $this->form_validation->set_rules('alamat','Alamat','required');
      $this->form_validation->set_rules('tema','Tema','required');
      $this->form_validation->set_rules('no_telp','Nomor Telepon','required');
      $this->form_validation->set_rules('email','email','required');
      $this->form_validation->set_rules('tgl','Tanggal','required');
            if($this->form_validation->run() != false){

        $config['upload_path'] = './assets/images/berkas/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '2048';
        $config['file_name'] = 'gambar'.time();

        $this->load->library('upload',$config);

        if($this->upload->do_upload('ktp')){
          $image = $this->upload->data();

        if($this->upload->do_upload('surat')){
          $image2 = $this->upload->data();

          $data = array(
            'ktp' => $image['file_name'],
            'surat' => $image2['file_name'],
            'id_user' => $this->session->userdata('id_user'),
            'nama_lengkap' => $nama_lengkap,
            'tempat_lahir' => $tempat_lahir,
            'tgl_lahir' => $tgl_lahir,
            'identitas' => $identitas,
            'univ' => $univ,
            'program_studi' => $program_studi,
            'matkul' => $matkul,
            'fakultas' => $fakultas,
            'pendidikan' => $pendidikan,
            'agama' => $agama,
            'alamat' => $alamat,
            'no_telp' => $no_telp,
            'email' => $email,
            'jenis_kelamin' => $jenis_kelamin,
            'no_surat' => $no_surat,
            'tema' => $tema,
            'awal_tgl' => $awal_tgl,
            'akhir_tgl' => $akhir_tgl,
            'tgl' => $tgl, 
          );
      
          $this->m_user->insert_data($data,'peneliti');
          $this->session->set_flashdata('info','*Berhasil');
     redirect(base_url('Kesbang/cetak_surat'));
        }else{
          $this->load->view('cetak_bukti');
    }
      }
  } 
  }
}