<!doctype html>
<html class="no-js" lang="zxx">
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Bakesbangpol Kab.Bekasi</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Favicons -->
  <link rel="shortcut icon" href="images/logo/Bekasi.jpg">


<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <script language='JavaScript'>

    
var txt=" Bakesbangpol Kab.Bekasi | ";
var speed=250;
var refresh=null;
function action() { document.title=txt;
txt=txt.substring(1,txt.length)+txt.charAt(0);
refresh=setTimeout("action()",speed);}action();
</script>

  <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
  <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">


  <link href='<?php echo base_url() ?>assets/images/Bekasi.jpg' rel='shortcut icon'>
  <link rel="shortcut icon" href="<?php echo base_url() ?>assets/images/logo/bsi.jpg">
  <link rel="apple-touch-icon" href="images/halima.png">
  <!-- Google font (font-family: 'Lobster', Open+Sans;) -->
  <link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Lobster+Two:400,400i,700,700i" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet">

  <!-- Stylesheets -->
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/plugins.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/style.css">

  <!-- Cusom css -->
   <link rel="stylesheet" href="<?php echo base_url()?>assets/css/custom.css">

  <!-- Modernizer js -->
  <script src="<?php echo base_url()?>assets/js/vendor/modernizr-3.5.0.min.js"></script>
</head>
<body>
  <!--[if lte IE 9]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->

  <!-- Add your site or application content here -->
  
  <!-- <div class="fakeloader"></div> -->

  <!-- Main wrapper -->
  <div class="wrapper" id="wrapper">
    <!-- Header -->
    <header id="header" class="jnr__header header--one clearfix">
      <!-- Start Header Top Area -->
          
      </div>
      <!-- End Header Top Area -->
      <!-- Start Mainmenu Area -->
      <div class="mainmenu__wrapper bg__cat--1 poss-relative header_top_line sticky__header">
        <div cl  ass="container">
          <div class="row d-none d-lg-flex">
            <div class="col-sm-4 col-md-6 col-lg-2 order-1 order-lg-1">
              <div class="logo">
                <a href="<?php echo base_url()?>assets/index.html">
                  <img src="<?php echo base_url()?>assets/images/logo/Bekasi.jpg" alt="logo images">
                </a>
              </div>
            </div>
            <div class="col-sm-4 col-md-2 col-lg-9 order-3 order-lg-2">
              <div class="mainmenu__wrap">
                <nav class="mainmenu__nav">
                                    <ul class="mainmenu">
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/index">Home</a></li>
                                        <li class="drop"><a href="#">Pendaftaran</a>
                                            <ul class="dropdown__menu">
                                                <li><a href="<?php echo base_url()?>kesbang/pendaftaran">Penelitian</a></li>
                                            </ul>
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/tentang">Tentang</a></li>
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/gallery">Gallery</a></li>
                                        <li><a href="<?php echo base_url()?>kesbang/kontak">Kontak</a></li>
                                    </ul>
                                </nav>
              </div>
            </div>
            </div>
          </div>
          <!-- Mobile Menu -->
                    <div class="mobile-menu d-block d-lg-none">
                      <div class="logo">
                        <a href="<?php echo base_url()?>assets/index.html"><img src="<?php echo base_url()?>assets/images/logo/halima.png" alt="logo"></a>
                      </div>
                    </div>
                    <!-- Mobile Menu -->
        </div>
      </div>			
      <!-- End Mainmenu Area -->
		</header>
		<!-- //Header -->
        <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area">
            <div class="ht__bradcaump__container">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="bradcaump__inner text-center">
                                <h2 class="bradcaump-title">Contact Us</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
        <section class="page__contact bg--white section-padding--lg">
        	<div class="container">
        		<div class="row">
        			<!-- Start Single Address -->
        			<div class="col-md-6 col-sm-6 col-12 col-lg-4">
        				<div class="address location">
        					<div class="ct__icon">
        						<i class="fa fa-home"></i>
        					</div>
							<div class="address__inner">
								<h2>Location</h2>
								<ul>
									<li><a href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.218973123066!2d107.17155376192237!3d-6.36570123979232!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e698c30643409e5%3A0x5f8346a27e2f61f8!2sKantor%20Bupati%20Bekasi!5e0!3m2!1sid!2sid!4v1575257254891!5m2!1sid!2sid">Kantor Bupati Bekasi, desa Sukamahi <br>  Kecamatan Cikarang Pusat,Kabupaten Bekasi,Jawa Barat<</li>
								</ul>
							</div>
        				</div>
        			</div>
        			<!-- End Single Address -->
        			<!-- Start Single Address -->
        			<div class="col-md-6 col-sm-6 col-12 col-lg-4 xs-mt-60">
        				<div class="address phone">
        					<div class="ct__icon">
        						<i class="fa fa-phone"></i>
        					</div>
							<div class="address__inner">
								<h2>Phone Number</h2>
									<li><a href="021-89970065">tell:021-89970065</a></li>
									<li><a href="021-89970129">tell:021-89970129</a></li>
									<li><a href="021-89970064">Fax:021-89970064</a></li>
								</ul>
							</div>
        				</div>
        			</div>
        			<!-- End Single Address -->
        			<!-- Start Single Address -->
        			<div class="col-md-6 col-sm-6 col-12 col-lg-4 md-mt-60 sm-mt-60">
        				<div class="address email">
        					<div class="ct__icon">
        						<i class="fa fa-envelope"></i>
        					</div>
							<div class="address__inner">
								<h2>E-mail Address</h2>
								<ul>
									<li><a href="mailto:badankesbangpol_kab.bekasi@gmail.com">badankesbangpol_kab.bekasi@gmail.com</a></li>
									<br></br>
								</ul>
							</div>
        				</div>
        			</div>
        			<!-- End Single Address -->
        		</div>
        	</div>
        </section>
        <div class="contact__map">
        	<div class="container-fluid">
        		<div class="row">
        			<div class="col-lg-7">
        				<div class="google__map">

        					<body> id="<iframe src=" https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.218973123066!2d107.17155376192237!3d-6.36570123979232!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e698c30643409e5%3A0x5f8346a27e2f61f8!2sKantor%20Bupati%20Bekasi!5e0!3m2!1sid!2sid!4v1575257254891!5m2!1sid!2sid" width="1650" height="650" frameborder="0" style="border:0;" allowfullscreen=""></iframe>"></div>  </body>
        					
        				</div>
        			</div>
        <!-- Start Contact Form -->
        <section class="contact__box section-padding--lg bg-image--27">
        	<div class="container">
        		<div class="row">
        			<div class="col-lg-12 col-sm-12 col-md-12">
						<div class="section__title text-center">
							<h2 class="title__line">Kritik Dan Saran</h2>
						</div>
					</div>
        		</div>
        		<div class="row mt--80">
        			<div class="col-lg-12">
    				<div class="contact-form-wrap">
              
              <form action="<?php echo base_url().'kesbang/buku_tamu' ?>" method="post" enctype="multipart/form-data" id="contact-form">
                <font color=red><b><?php 
$info = $this->session->flashdata('info');
if($info)
{?>
  
  <i class="icon-ok green"></i>
<?php
echo $info;
}
?></b></font>

                                <div class="single-contact-form name">
                                    <input type="text" name="nama_lengkap" placeholder="Your Name*">
                                    <input type="email" name="email" placeholder="Mail*">
                                </div>
                                <div class="single-contact-form subject">
                               		<input type="text" name="subjek" placeholder="Subject*">
                                </div>
                                <div class="single-contact-form message">
                                    <textarea name="pesan"  placeholder="Type your message here.."></textarea>
                                </div>
                                <div class="contact-btn">
                                    <button type="submit" class="dcare__btn">submit</button>
                                </div>
                            </form>
                        </div> 
                        <div class="form-output">
                            <p class="form-messege"></p>
                        </div>
        			</div>
        		</div>
        	</div>
        </section>
        <!-- End Contact Form -->
		<!-- Footer Area -->
		
	<!-- JS Files -->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

    <!-- Google Map js -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmGmeot5jcjdaJTvfCmQPfzeoG_pABeWo"></script>
    <script>
        // When the window has finished loading create our google map below
        google.maps.event.addDomListener(window, 'load', init);

        function init() {
            // Basic options for a simple Google Map
            // For more options see: https://developers.google.com/maps/documentation/javascript/reference#MapOptions
            var mapOptions = {
                // How zoomed in you want the map to start at (always required)
                zoom: 12,

                scrollwheel: false,

                // The latitude and longitude to center the map (always required)
                center: new google.maps.LatLng(23.7286, 90.3854), // New York

                // How you would like to style the map. 
                // This is where you would paste any style found on Snazzy Maps.
                 styles:
				[
				    {
				        "featureType": "all",
				        "elementType": "all",
				        "stylers": [
				            {
				                "invert_lightness": true
				            },
				            {
				                "saturation": 10
				            },
				            {
				                "lightness": 30
				            },
				            {
				                "gamma": 0.5
				            },
				            {
				                "hue": "#435158"
				            }
				        ]
				    },
				    {
				        "featureType": "administrative.province",
				        "elementType": "labels.text.stroke",
				        "stylers": [
				            {
				                "hue": "#ff00d0"
				            }
				        ]
				    }
				]
            };

            // Get the HTML DOM element that will contain your map 
            // We are using a div with id="map" seen below in the <body>
            var mapElement = document.getElementById('googleMap');

            // Create the Google Map using our element and options defined above
            var map = new google.maps.Map(mapElement, mapOptions);

            // Let's also add a marker while we're at it
            var marker = new google.maps.Marker({
                position: new google.maps.LatLng(23.7286, 90.3854),
                map: map,
                title: 'Dcare!',
                icon: 'images/icons/map.png',
                animation:google.maps.Animation.BOUNCE

            });
        }
    </script>



	<script src="js/plugins.js"></script>
	<script src="js/active.js"></script>
</body>
</html>



