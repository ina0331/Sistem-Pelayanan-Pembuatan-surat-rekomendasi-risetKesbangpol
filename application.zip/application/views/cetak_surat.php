<!doctype html>
<html class="no-js" lang="zxx">
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Bakesbangpol Kab.Bekasi</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Favicons -->
  <link rel="shortcut icon" href="images/logo/Bekasi.jpg">


<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <script language='JavaScript'>

    
var txt=" Bakesbangpol Kab.Bekasi | ";
var speed=250;
var refresh=null;
function action() { document.title=txt;
txt=txt.substring(1,txt.length)+txt.charAt(0);
refresh=setTimeout("action()",speed);}action();
</script>


  <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
  <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">


  <link href='<?php echo base_url() ?>assets/images/Bekasi.jpg' rel='shortcut icon'>
  <link rel="shortcut icon" href="<?php echo base_url() ?>assets/images/logo/bsi.jpg">
  <link rel="apple-touch-icon" href="images/halima.png">
  <!-- Google font (font-family: 'Lobster', Open+Sans;) -->
  <link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Lobster+Two:400,400i,700,700i" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet">

  <!-- Stylesheets -->
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/plugins.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/style.css">

  <!-- Cusom css -->
   <link rel="stylesheet" href="<?php echo base_url()?>assets/css/custom.css">

  <!-- Modernizer js -->
  <script src="<?php echo base_url()?>assets/js/vendor/modernizr-3.5.0.min.js"></script>
</head>
<body>
  <!--[if lte IE 9]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->

  <!-- Add your site or application content here -->
  
  <!-- <div class="fakeloader"></div> -->

  <!-- Main wrapper -->
  <div class="wrapper" id="wrapper">
    <!-- Header -->
    <header id="header" class="jnr__header header--one clearfix">
      <!-- Start Header Top Area -->
          
      </div>
      <!-- End Header Top Area -->
      <!-- Start Mainmenu Area -->
      <div class="mainmenu__wrapper bg__cat--1 poss-relative header_top_line sticky__header">
        <div cl  ass="container">
          <div class="row d-none d-lg-flex">
            <div class="col-sm-4 col-md-6 col-lg-2 order-1 order-lg-1">
              <div class="logo">
                <a href="<?php echo base_url()?>assets/index.html">
                  <img src="<?php echo base_url()?>assets/images/logo/Bekasi.jpg" alt="logo images">
                </a>
              </div>
            </div>
            <div class="col-sm-4 col-md-2 col-lg-9 order-3 order-lg-2">
              <div class="mainmenu__wrap">
                <nav class="mainmenu__nav">
                                    <ul class="mainmenu">
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/index">Home</a></li>
                                        <li class="drop"><a href="#">Pendaftaran</a>
                                            <ul class="dropdown__menu">
                                                <li><a href="<?php echo base_url()?>kesbang/upload">Penelitian</a></li>
                                              </ul>
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/tentang">Tentang</a></li>
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/gallery">Gallery</a></li>
                                        <li><a href="<?php echo base_url()?>kesbang/kontak">Kontak</a></li>
                                         <?php if($id_user = $this->session->userdata('id_user')) { ?>
            <?php $data_user = $this->m_user->get_data2('user',$id_user)->row_array(); echo $data_user['nama_lengkap'];?>
           

            <?php echo anchor('kesbang/logout', ' &nbsp Logout');?></li>

        <?php } else { ?>
            <?php echo anchor('kesbang/login_user', 'Login');?></li>
        <?php } ?> 
                                    </ul>
                                </nav>
              </div>
            </div>
            </div>
          </div>
          <!-- Mobile Menu -->
                   
    <!-- End Slider Area -->
    <!-- Start Our Gallery Area -->
    <section class="junior__gallery__area bg--white section-padding--lg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 col-sm-12 col-md-12">
            <div class="section__title text-center">
              <h2 class="title__line">CETAK SURAT</h2>
              <p></p>
            </p>
            </div>
          </div>
        </div> 
        <div class="table-responsive">
  <table class="table table-bordered table-striped table-hover">
    <thead>
   
<h1 align="center"><a class="btn btn-warning btn-md" href="<?php echo base_url().'admin/laporan_pdf_booking' ?>">
  <span class="glyphicon glyphicon-pdf"></span>
Cetak PDF</a> </h1>

<br>
 <h1 align="center"><a href="<?php echo base_url().'Kesbang/laporan_print_surat'; ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus"></span> print</a></h1>
        
  </tbody>
</table>
</div>

       
          
              
    </section>
    <!-- End Our Gallery Area -->
    <!-- Start Blog Area -->
    <!-- End Blog Area -->
      
          </div>
        </div>
        <div class="ft__bottom__images--1 wow flipInX" data-wow-delay="0.6s">
          <img src="<?php echo base_url()?>assets/images/banner/mid-img/ft.png" alt="footer images">
        </div>
        <div class="ft__bottom__images--2 wow fadeInRight" data-wow-delay="0.6s">
          <img src="<?php echo base_url()?>assets/images/banner/mid-img/ft-2.png" alt="footer images">
        </div>
      </div>
      <!-- .Start Footer Contact Area -->
      <!-- .End Footer Contact Area -->
      <div class="copyright  bg--theme">
        <div class="container">
          <div class="row align-items-center copyright__wrapper justify-content-center">
            <div class="col-lg-12 col-sm-12 col-md-12">
              <div class="coppy__right__inner text-center">
                <p>Copyright <i class="fa fa-copyright"></i> 2019 <a href="https://freethemescloud.com/" target="_blank" >Kesbangpol.</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- //Footer Area -->
        <!-- Login Form -->
       
  </div><!-- //Main wrapper -->

  <!-- JS Files -->
  <script src="<?php echo base_url()?>assets/js/vendor/jquery-3.2.1.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/plugins.js"></script>
  <script src="<?php echo base_url()?>assets/js/active.js"></script>
</body>
</html>
