<!doctype html>
<html class="no-js" lang="zxx">
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Bakesbangpol Kab.Bekasi</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Favicons -->
  <link rel="shortcut icon" href="images/logo/Bekasi.jpg">


<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <script language='JavaScript'>

    
var txt=" Bakesbangpol Kab.Bekasi | ";
var speed=250;
var refresh=null;
function action() { document.title=txt;
txt=txt.substring(1,txt.length)+txt.charAt(0);
refresh=setTimeout("action()",speed);}action();
</script>


  <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
  <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">


  <link href='<?php echo base_url() ?>assets/images/Bekasi.jpg' rel='shortcut icon'>
  <link rel="shortcut icon" href="<?php echo base_url() ?>assets/images/logo/bsi.jpg">
  <link rel="apple-touch-icon" href="images/halima.png">
  <!-- Google font (font-family: 'Lobster', Open+Sans;) -->
  <link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Lobster+Two:400,400i,700,700i" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet">

  <!-- Stylesheets -->
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/plugins.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/style.css">

  <!-- Cusom css -->
   <link rel="stylesheet" href="<?php echo base_url()?>assets/css/custom.css">

  <!-- Modernizer js -->
  <script src="<?php echo base_url()?>assets/js/vendor/modernizr-3.5.0.min.js"></script>
</head>
<body>
  
  <!--[if lte IE 9]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->

  <!-- Add your site or application content here -->
  
  <!-- <div class="fakeloader"></div> -->

  <!-- Main wrapper -->
  <div class="wrapper" id="wrapper">
    <!-- Header -->
    <header id="header" class="jnr__header header--one clearfix">
      <!-- Start Header Top Area -->
          
      </div>
      <!-- End Header Top Area -->
      <!-- Start Mainmenu Area -->
      <div class="mainmenu__wrapper bg__cat--1 poss-relative header_top_line sticky__header">
        <div cl  ass="container">
          <div class="row d-none d-lg-flex">
            <div class="col-sm-4 col-md-6 col-lg-2 order-1 order-lg-1">
              <div class="logo">
                <a href="<?php echo base_url()?>assets/index.html">
                  <img src="<?php echo base_url()?>assets/images/logo/Bekasi.jpg" alt="logo images">
                </a>
              </div>
            </div>
            <div class="col-sm-4 col-md-2 col-lg-9 order-3 order-lg-2">
              <div class="mainmenu__wrap">
                <nav class="mainmenu__nav">
                                    <ul class="mainmenu">
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/index">Home</a></li>
                                        <li class="drop"><a href="#">Pendaftaran</a>
                                            <ul class="dropdown__menu">
                                                <li><a href="<?php echo base_url()?>kesbang/upload">Penelitian</a></li>
                                              </ul>
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/tentang">Tentang</a></li>
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/gallery">Gallery</a></li>
                                        <li><a href="<?php echo base_url()?>kesbang/kontak">Kontak</a></li>
                                         <?php if($id_user = $this->session->userdata('id_user')) { ?>
            <?php $data_user = $this->m_user->get_data2('user',$id_user)->row_array(); echo $data_user['nama_lengkap'];?>
           

            <?php echo anchor('kesbang/logout', ' &nbsp Logout');?></li>

        <?php } else { ?>
            <?php echo anchor('kesbang/login_user', 'Login');?></li>
        <?php } ?> 
                                    </ul>
                                </nav>
              </div>
            </div>
            </div>
          </div>
          <!-- Mobile Menu -->
                  
      <!-- End Mainmenu Area -->
    </header>
    <!-- //Header -->
   
             
        
            </div>
          </div>
        </div>
      </div>
    </div>
   
    <!-- End Slider Area -->
     <form action="<?php echo base_url().'Kesbang/upload' ?>" method="post" enctype="multipart/form-data">
  <br>
<font color=blue><p align="right"><b><?php 
$info = $this->session->flashdata('info');
if($info)
{?>
  <div class="alert alert-danger alert-success">
  <i class="icon-ok green"></i>
<?php
echo $info;
}
?></b></p></font>

    
    <div class="col-md-4">
    <div class="form-group">
      <label>Nama</label>
      <input type="text" name="nama_lengkap" class="form-control"  placeholder="Masukkan Nama Anda" />
      
      </div>
    </div>

      <div class="col-md-4">
    <div class="form-group">
      <label>Tempat Lahir</label>
      <input type="text" name="tempat_lahir" class="form-control"  placeholder="Masukkan Tempat Lahir" />
      </div>
      </div>


       <div class="col-md-4">
    <div class="form-group">
      <label>Tanggal Lahir</label>
      <input type="date" name="tgl_lahir" class="form-control"  placeholder="Masukkan tgl Lahir" />
      </div>
    </div>

    <div class="col-md-4">
    <div class="form-group">
            <label>Jenis Kelamin</label>
          <select name="jenis_kelamin" class="form-control" data-rule="" placeholder="-Pilih-">
            <option value="Laki-Laki">Laki-Laki</option>
            <option value="Perempuan">Perempuan</option>
           </select>
      </div>
    </div>

       <div class="col-md-4">
    <div class="form-group">
      <label>NIM</label>
      <input type="number" name="identitas" class="form-control"  placeholder="Masukkan NIM" />
      </div>
    </div>
       <div class="col-md-4">
    <div class="form-group">
      <label>Universitas</label>
      <input type="text" name="univ" class="form-control"  placeholder="Masukkan Universitas" />
      </div>
    </div>


       <div class="col-md-4">
    <div class="form-group">
      <label>Program Studi</label>
      <input type="text" name="program_studi" class="form-control"  placeholder="Masukkan program Studi" />
      </div>
    </div>


       <div class="col-md-4">
    <div class="form-group">
      <label>Mata Kuliah</label>
      <input type="text" name="matkul" class="form-control"  placeholder="Masukkan Mata Kuliah" />
      </div>
      </div>

       <div class="col-md-4">
    <div class="form-group">
      <label>Fakultas</label>
      <input type="text" name="fakultas" class="form-control"  placeholder="Masukkan Fakultas" />
      </div>
    </div>


       <div class="col-md-4">
    <div class="form-group">
      <label>Pendidikan</label>
          <select name="pendidikan" class="form-control" data-rule="" placeholder="-Pilih-">
            <option value="D3">D3</option>
            <option value="S1">S1</option>
            <option value="S2">S2</option>
            <option value="S3">S3</option>
           </select>
      </div>
    </div>

       <div class="col-md-4">
    <div class="form-group">
      <label>Agama</label>
      <input type="text" name="agama" class="form-control"  placeholder="Masukkan Agama" />
      </div>
    </div>
       <div class="col-md-4">
    <div class="form-group">
      <label>Alamat</label>
      <input type="text" name="alamat" class="form-control"  placeholder="Masukkan Alamat" />
      </div>
    </div>
        <div class="col-md-4">
    <div class="form-group">
      <label>No telepon</label>
      <input type="number" name="no_telp" class="form-control"  placeholder="Masukkan nomor telepon" />
      </div>
    </div>

 
       <div class="col-md-4">
    <div class="form-group">
      <label>Email</label>
      <input type="text" name="email" class="form-control"  placeholder="Masukkan Email" />
      </div>
    </div>


       <div class="col-md-4">
       <div class="form-group">
      <label>Tanggal Pengajuan</label>
      <input type="date" name="tgl" class="form-control" /> 
     </div>
   </div>

   <div class="col-md-4">
    <div class="form-group">
      <label>Nomor Surat</label>
      <input type="text" name="no_surat" class="form-control"  placeholder="Masukkan nomor surat" />
      </div>
    </div>

       <div class="col-md-4">
    <div class="form-group">
      <label> Tema Penelitian</label>
      <input type="text" name="tema" class="form-control"  placeholder="Masukkan Tema" />
      </div>
</div>

       <div class="col-md-4">
    <div class="form-group">
      <label>Waktu Pelaksanaan</label>
      <input type="date" name="awal_tgl" class="form-control"  placeholder="Masukkan Universitas" />
      </div>
    </div>


       <div class="col-md-4">
    <div class="form-group">
      <label>s/d</label>
      <input type="date" name="akhir_tgl" class="form-control"  placeholder="Masukkan Universitas" />
      </div>

    </div>
<div class="form-group">
<label> Upload Scan KTP  </label>
            <input type="file" class="form-control-file" name="ktp"></div>
            <label> Upload Scan Surat Pengantar dari kampus </label>
            <input type="file" class="form-control-file" name="surat">
            <small><font color=red>*file maksimal dengan ukuran 2MB PNG/JPG/JPEG</small>
            </font>
          </small>
        </div> 
      </div>
                        <div class="col-md-12">
                          <button type="submit" class="btn btn-primary">Simpan</button>
                          <button type="reset" class="btn btn-danger">RESET</button>
                        </div>
</form>

  <!-- JS Files -->
  <script src="js/vendor/jquery-3.2.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/plugins.js"></script>
  <script src="js/active.js"></script>
</body>
</html>














