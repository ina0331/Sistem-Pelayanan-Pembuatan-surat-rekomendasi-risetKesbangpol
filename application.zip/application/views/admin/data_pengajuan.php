   <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
              
                    <div class="col-md-12"><div class="page-header">
  <h3 align="center">DATA PENGAJUAN SURAT PENELITIAN</h3>
</div>

<br><br> 
<font color=blue><b><?php 
$info = $this->session->flashdata('info');
if($info)
{?>
  
  <i class="icon-ok green"></i>
<?php
echo $info;
}
?></b></font>
<br>
<div class="table-responsive">
  <table class="table table-bordered table-striped table-hover">
    <thead>
      <tr>
        <th>No</th>
        <th>ID User</th>
        <th>Tanggal Pengajuan</th>
        <th>Nama Lengkap</th>  
        <th>NIM</th>  
        <th>Universitas</th>
        <th>Program Studi</th>
        <th>Fakultas</th>
        <th>Nomor Surat</th>
        <th>Tema</th> 
        <th>Tanggal pelaksanaan</th>  
        <th>Akhir Pelaksanaan</th> 
        <th>KTP</th>
        <th>Surat</th>     

        <th>Pilihan</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $no = 1;
      foreach ($data_pengajuan as $a) {
      ?>
      <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo $a->id_user ?></td>
         <td><?php echo $a->tgl ?></td>
        <td><?php echo $a->nama_lengkap ?></td>
        <td><?php echo $a->identitas ?></td>
        <td><?php echo $a->univ ?></td>
        <td><?php echo $a->program_studi ?></td>
        <td><?php echo $a->fakultas ?></td>
        <td><?php echo $a->no_surat ?></td>
        <td><?php echo $a->tema ?></td>
        <td><?php echo $a->awal_tgl ?></td>
        <td><?php echo $a->akhir_tgl ?></td>
        <td><img src="<?php echo base_url().'./assets/images/berkas/'.$a->ktp; ?>" width="100" height="100"></td>
        <td><img src="<?php echo base_url().'./assets/images/berkas/'.$a->surat; ?>" width="100" height="100"></td>
        <td nowrap="nowrap">
          <a class="btn btn-warning btn-xs" href="<?php echo base_url().'admin/hapus_pengajuan/'.$a->id_peneliti; ?>"><span class="glyphicon glyphicon-remove">Hapus</span></a>
      </td>
      </tr>
    <?php } ?>
  </tbody>
</table>
</div>

                                                          <div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


