   <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
              
                    <div class="col-md-12"><div class="page-header">
  <h3 align="center">BUKU TAMU</h3>
</div>
 
<br><br> 
<font color=blue><b><?php 
$info = $this->session->flashdata('info');
if($info)
{?>
  
  <i class="icon-ok green"></i>
<?php
echo $info;
}
?></b></font>
<br>
<div class="table-responsive">
  <table class="table table-bordered table-striped table-hover">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama Lengkap</th>
        <th>Email</th>
        <th>Subject</th>  
        <th>Pesan</th>  
        <th>Pilihan</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $no = 1;
      foreach ($bukutamu as $a) {
      ?>
      <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo $a->nama_lengkap ?></td>
        <td><?php echo $a->email ?></td>
        <td><?php echo $a->subjek ?></td>
        <td><?php echo $a->pesan ?></td>
        <td nowrap="nowrap">

          <a class="btn btn-warning btn-xs" href="<?php echo base_url().'admin/hapus_bukutamu/'.$a->id_bukutamu; ?>"><span class="glyphicon glyphicon-remove">Hapus</span></a>
      </td>
      </tr>
    <?php } ?>
  </tbody>
</table>
</div>

                                                          <div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>

