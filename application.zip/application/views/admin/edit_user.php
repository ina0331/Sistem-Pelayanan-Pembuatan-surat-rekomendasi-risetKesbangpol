<!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                
                    <div class="col-md-12"><div class="page-header">
  <h3 align="center">Edit Anggota</h3>
</div>
<?php foreach ($data_user as $a){ ?>
<form action="<?php echo base_url().'admin/update_user' ?>" method="post" enctype="multipart/form-data">

<div class="form-group">
    <label>&nbsp;&nbsp;Id User</label>
    <input type="hidden" name="id" value="<?php echo $a->id_user; ?>">
    <input type="id" name="id_user" class="form-control" value="<?php echo $a->id_user; ?>">
    <?php echo form_error('id_user'); ?>
  </div> 

  <div class="form-group">
      <label>&nbsp;&nbsp;Nama Aggota</label>
      <input type="hidden" name="nama_lengkap" value="<?php echo $a->id_user; ?>">
      <input type="text" name="nama_lengkap" class="form-control" value="<?php echo $a->nama_lengkap; ?>">
      <?php echo form_error('nama_lengkap'); ?>
    </div>

 <div class="form-group">
      <label>&nbsp;&nbsp;Email</label>
      <input type="hidden" name="email" value="<?php echo $a->id_user; ?>">
      <input type="text" name="email" class="form-control" value="<?php echo $a->email; ?>">
      <?php echo form_error('email'); ?>
    </div>

    <div class="form-group">
      <label>&nbsp;&nbsp;Username</label>
      <input type="hidden" name="username" value="<?php echo $a->id_user; ?>">
      <input type="md5" name="username" class="form-control" value="<?php echo $a->username; ?>">
      <?php echo form_error('username'); ?>
    </div>

     <div class="form-group">
      <label>&nbsp;&nbsp;Password</label>
      <input type="hidden" name="password" value="<?php echo $a->id_user; ?>">
      <input type="password" name="password" class="form-control" value="<?php echo $a->password; ?>">
      <?php echo form_error('password'); ?>
    </div>

<div class="form-group">
      <label>&nbsp;&nbsp;No.telepon</label>
      <input type="hidden" name="no_telp" value="<?php echo $a->id_user; ?>">
      <input type="number" name="no_telp" class="form-control" value="<?php echo $a->no_telp; ?>">
      <?php echo form_error('no_telp'); ?>
    </div>

 
 
  <div class="form-group">
   &nbsp;&nbsp; <input type="submit" value="Update" class="btn btn-primary">
		<input type="button" value="Kembali" class="btn btn-primary" onclick="window.history.go(-1)">
  </div>
  </form>

                                                          <div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>
  <?php } ?>

