  <h3 class="page-title">
              Selamat Datang
              <small>dihalaman Admin</small>
            </h3>
  <?php $this->load->view('admin/head'); ?>
 <section class="content">
          <!-- Small boxes (Stat box) -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box --> 
              <div class="small-box bg-aqua">
                <div class="inner">
                 <font size="18"><b><?php echo $this->m_admin->get_data('buku_tamu')->num_rows(); ?></b></font>
                  <p><b>TOTAL KRITIK DAN SARAN</b></p>
                </div>
                <div class="icon">
                  <i class="fa fa-comments-o"></i>
                </div>
                 <a href="<?php echo base_url().'admin/bukutamu' ?>" class="small-box-footer">Lihat Selengkapnya<i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <font size="18"><b><?php echo $this->m_admin->get_data('peneliti')->num_rows(); ?></b></font>
                  <p><b>TOTAL PENGAJUAN</b></p>
                </div>
                <div class="icon">
                  <i class="fa fa-folder"></i>
                </div>
                <a href="<?php echo base_url().'admin/data_pengajuan' ?>" class="small-box-footer">Lihat Selengkapnya<i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                   <font size="18"><b><?php echo $this->m_admin->get_data('user')->num_rows(); ?></b></font>
                  <p><b>TOTAL ANGGOTA</b></p>
                </div>
                <div class="icon">
                  <i class="fa fa-users"></i>
                </div>
                <a href="<?php echo base_url().'admin/data_user' ?>" class="small-box-footer">Lihat Selengkapnya <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red">
                <div class="inner">
                  <font size="18"><b><?php echo $this->m_admin->get_data('admin')->num_rows(); ?></b></font>
                  <p><b>TOTAL ADMIN</b></p>
                </div>
                <div class="icon">
                  <i class="fa fa-users"></i>
                </div>
                <a href="<?php echo base_url().'admin/data_admin' ?>" class="small-box-footer">Lihat Selengkapnya<i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
          
       
