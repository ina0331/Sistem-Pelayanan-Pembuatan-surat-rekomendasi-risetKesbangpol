<!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
          
                    <div class="col-md-12"><div class="page-header">
	<h3 style="position: relative; right: : 25%">&nbsp;&nbsp;Data Admin</h3>
</div>
<div style="position: relative; right: : 25%">
<table>
	<?php 
	// echo print_r($siswa);
		foreach ($admin as $e) {
	?>
	&nbsp;&nbsp;<tr><th>&nbsp;&nbsp;Nama Admin</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->nama_lengkap; ?></th></tr>
	<tr><th>&nbsp;&nbsp;Username</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->username; ?></th></tr>
	&nbsp;&nbsp;<tr><th>&nbsp;&nbsp;No.Telepon</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->no_telp; ?></th></tr>
	&nbsp;&nbsp;<tr><th>&nbsp;&nbsp;Id Admin</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->id_admin; ?></th></tr>
	&nbsp;&nbsp;<tr><th>&nbsp;&nbsp;Email</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->email; ?></th></tr>
	<?php } ?>
				</tbody>
				</table>
			</div>
		</td>
	</tr>
	<tr>
		&nbsp;
		<br><br>
		<td colspan="3">
		<td align="left">
			&nbsp;&nbsp;<a class="btn btn-sm btn-primary" href="<?php echo base_url().'admin'; ?>"><span class="glyphicon glyphicon-delete"></span> kembali</a>
		</td>
		<td>
	</tr>
</table>
</div>
</div>

                                                              <div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>

