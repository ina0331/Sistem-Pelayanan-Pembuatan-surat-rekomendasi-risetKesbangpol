   <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
              
                    <div class="col-md-12"><div class="page-header">
  <h3 align="center">CETAK LAPORAN</h3>
</div>

<br>
<div class="table-responsive">
  <table class="table table-bordered table-striped table-hover">
    <thead>
      <tr>
        <th>No</th>
        <th>LAPORAN</th> 
        <th>Pilihan</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $no = 1;
      ?>
      <tr>
        <td><?php echo $no++; ?></td>
        <td>PENGAJUAN SURAT</td>

        <td nowrap="nowrap">
        <h1 align="center"><a class="btn btn-warning btn-md" href="<?php echo base_url().'admin/laporan_print_pengajuan' ?>">
  <span class="glyphicon glyphicon-pdf"></span>
Cetak </a> </h1>
      </td>
      </tr>

      <tr>
        <td><?php echo $no++; ?></td>
        <td>DAFTAR ANGGOTA</td>

        <td nowrap="nowrap">
        <h1 align="center"><a class="btn btn-warning btn-md" href="<?php echo base_url().'admin/laporan_print_user' ?>">
  <span class="glyphicon glyphicon-pdf"></span>
Cetak </a> </h1>
      </td>
      </tr>
  </tbody>
</table>
</div>

                                                          <div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>

