<!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
           
                    <div class="col-md-12"><div class="page-header">

  <h3 align="center">Data Anggota Baru</h3>
</div>
<?= validation_errors('<p style="color:red;">','</p>'); ?>
<?php
if($this->session->flashdata()){
  echo "<div class='alert alert-danger alert-message'>";
  echo $this->session->flashdata('alert');
  echo "</div>";
} ?>
<form action="<?php echo base_url().'admin/tambah_data_user_act' ?>" method="post" enctype="multipart/form-data">


    <div class="form-group">
      <label>&nbsp;&nbsp;Nama Anggota</label>
      <input type="text" name="nama_lengkap" class="form-control">
      <?php echo form_error('nama_lengkap'); ?>
    </div>

 <div class="form-group">
      <label>&nbsp;&nbsp;Email</label>
      <input type="text" name="email" class="form-control">
      <?php echo form_error('email'); ?>
    </div>

    <div class="form-group">
      <label>&nbsp;&nbsp;username</label>
      <input type="text" name="username" class="form-control">
      <?php echo form_error('username'); ?>
    </div>

     <div class="form-group">
      <label>&nbsp;&nbsp;password</label>
      <input type="password" name="password" class="form-control">
      <?php echo form_error('password'); ?>
    </div>

<div class="form-group">
      <label>&nbsp;&nbsp;No.telepon</label>
      <input type="number" name="no_telp" class="form-control">
      <?php echo form_error('no_telp'); ?>
    </div>


    <div class="form-group">
      &nbsp;&nbsp;<input type="submit" value="Simpan" class="btn btn-primary">
    </div>
  </div>
</form>

                                                              <div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>
