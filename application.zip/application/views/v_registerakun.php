 <html lang="en">
<head>
  <title>Daftar Akun </title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
  <link rel="icon" type="<?php echo base_url()?>ass/image/png" href="<?php echo base_url()?>ass/images/icons/favicon.ico"/>
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>ass/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>ass/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>ass/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>ass/vendor/animate/animate.css">
<!--===============================================================================================-->  
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>ass/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>ass/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>ass/vendor/select2/select2.min.css">
<!--===============================================================================================-->  
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>ass/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>ass/css/util.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>ass/css/main.css">
<!--===============================================================================================-->
</head>
<body>
 
  <div class="limiter">
    <div class="container-login100" style="background-image: url('<?php echo base_url()?>ass/images/bg-01.jpg');">
      <div class="wrap-login100 p-t-30 p-b-50">
        <span class="login100-form-title p-b-41">
          Daftar Akun
        </span>
        <form action="<?php echo base_url().'kesbang/register_akun_act' ?>" method="post">

<br>
<font color=blue><p align="right"><b><?php 
$info = $this->session->flashdata('info');
if($info)
{?>
  <div class="alert alert-danger alert-success">
  <i class="icon-ok green"></i>
<?php
echo $info;
}
?></b></p></font>
<br>
<br>
 <div class="wrap-input100 validate-input" data-validate = "Enter Nama Anda">
            <input class="input100" type="text" name="nama_lengkap" id="username" placeholder="Nama Lengkap">
            <span class="focus-input100" data-placeholder="&#xe82a;"></span>
          </div>

 <div class="wrap-input100 validate-input" data-validate = "Enter username">
            <input class="input100" type="text" name="username" id="username" placeholder="Username">
            <span class="focus-input100" data-placeholder="&#xe82a;"></span>
          </div>

          <div class="wrap-input100 validate-input" data-validate="Enter password">
            <input class="input100" type="password" name="password" id="password" placeholder="Password">
            <span class="focus-input100" data-placeholder="&#xe80f;"></span>
          </div>

 <div class="wrap-input100 validate-input" data-validate = "Enter nomor">
            <input class="input100" type="number" name="no_telp" id="username" placeholder="Nomor Telepon">
            <span class="focus-input100" data-placeholder="&#xe82a;"></span>
          </div>
 <div class="wrap-input100 validate-input" data-validate = "Enter email">
            <input class="input100" type="text" name="email" id="username" placeholder="Email">
            <span class="focus-input100" data-placeholder="&#xe82a;"></span>
          </div>

<br>
<br>

  <center>
      <input type="submit" name="simpan" value="Simpan" class="btn btn-primary" /> 
      &nbsp;&nbsp; <input type="reset" value="Batal" class="btn btn-danger"/>
    </center>
<br>
<p> Sudah punya akun ? <a href="<?php echo base_url() ?>kesbang/login_user">LOGIN</a></p>
</form>
  
  <div id="dropDownSelect1"></div>
  
<!--===============================================================================================-->
  <script src="<?php echo base_url()?>ass/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
  <script src="<?php echo base_url()?>ass/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
  <script src="<?php echo base_url()?>ass/vendor/bootstrap/js/popper.js"></script>
  <script src="<?php echo base_url()?>ass/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
  <script src="<?php echo base_url()?>ass/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
  <script src="<?php echo base_url()?>ass/vendor/daterangepicker/moment.min.js"></script>
  <script src="<?php echo base_url()?>ass/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
  <script src="<?php echo base_url()?>ass/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
  <script src="<?php echo base_url()?>ass/js/main.js"></script>

</body>
</html>
 