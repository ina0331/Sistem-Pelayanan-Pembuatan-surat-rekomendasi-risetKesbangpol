<!doctype html>
<html class="no-js" lang="zxx">
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Gallery Bakesbangpol Kab.Bekasi</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Favicons -->
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/icon.png">
	<!-- Google font (font-family: 'Lobster', Open+Sans;) -->
	<link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Lobster+Two:400,400i,700,700i" rel="stylesheet">
	<link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
	<link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/plugins.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/style.css">

	<!-- Cusom css -->
   <link rel="stylesheet" href="<?php echo base_url()?>assets/css/custom.css">

	<!-- Modernizer js -->
	<script src="<?php echo base_url()?>assets/js/vendor/modernizr-3.5.0.min.js"></script>
</head>
<body>
	<!--[if lte IE 9]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
	<![endif]-->

	<!-- Add your site or application content here -->
	
	<!-- <div class="fakeloader"></div> -->

	<!-- Main wrapper -->
	<div class="wrapper" id="wrapper">
		
		<!-- Header -->
		<header id="header" class="jnr__header header--2 clearfix">
			<!-- Start Mainmenu Area -->
			<div class="mainmenu__wrapper bg--white sticky__header">
				<div class="container">
					<div class="row d-none d-lg-flex">
						<div class="col-sm-4 col-md-6 col-lg-2 order-1 order-lg-1">
							<div class="logo">
								<a href="<?php echo base_url()?>assets/index.html">
									<img src="<?php echo base_url()?>assets/images/logo/bekasi.jpg" alt="logo images">
								</a>
							</div>
						</div>
						<div class="col-sm-4 col-md-2 col-lg-9 order-3 order-lg-2">
							<div class="mainmenu__wrap">
								<nav class="mainmenu__nav">
                                    <ul class="mainmenu">
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/index">Home</a></li>
                                        <li class="drop"><a href="#">Pendaftaran</a>
                                            <ul class="dropdown__menu">
                                                <li><a href="<?php echo base_url()?>kesbang/peneliti">Penelitian</a></li>
                                              </ul>
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/gallery">Gallery</a></li>
                                        <li><a href="<?php echo base_url()?>kesbang/kontak">Kontak</a></li>
                                </nav>
							</div>
						</div>
						<div class="col-lg-1 col-sm-4 col-md-4 order-2 order-lg-3">
							<div class="shopbox d-flex justify-content-end align-items-center">
							</div>
						</div>
					</div>
					<!-- Mobile Menu -->
                    <div class="mobile-menu d-block d-lg-none">
                    	<div class="logo">
                    		<a href="<?php echo base_url()?>assets/index.html"><img src="<?php echo base_url()?>assets/images/logo/bekasi.jpg" alt="logo"></a>
                    	</div>
                    	<a class="minicart-trigger" href="<?php echo base_url()?>assets/#">
                    		<i class="fa fa-shopping-basket"></i>
                    </div>
                    <!-- Mobile Menu -->
				</div>
			</div>
			<!-- End Mainmenu Area -->
		</header>
		<!-- //Header -->
        <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area">
      
                        <div class="col-lg-12">
                            <div class="bradcaump__inner text-center">
                                <h2 class="bradcaump-title">Gallery</h2>
                                <nav class="bradcaump-inner">
                                  <a class="breadcrumb-item" href="index.html">Home</a>
                                  <span class="brd-separetor"><img src="<?php echo base_url()?>assets/images/icons/brad.png" alt="separator images"></span>
                                  <span class="breadcrumb-item active">Gallery</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
		<!-- Start Our Gallery Area -->
		<div class="junior__gallery__area gallery-page-one gallery__masonry__activation gallery--3 bg-image--25 section-padding--lg">
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						<div class="gallery__menu">
                            <button data-filter="*"  class="is-checked">All</button>
                            <button data-filter=".cat--1"></button>
                            <button data-filter=".cat--2"></button>
                            <button data-filter=".cat--3"></button>
                      	</div>
					</div>
				</div>
				<div class="row galler__wrap masonry__wrap mt--80">
					<!-- Start Single Gallery -->
					<div class="col-lg-3 col-md-4 col-sm-6 col-12 gallery__item cat--2">
						<div class="gallery">
							<div class="gallery__thumb">
								<a href="<?php echo base_url()?>assets/#">
									<img src="<?php echo base_url()?>assets/images/gallery/gl-page-one/1.jpg" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="<?php echo base_url()?>assets/images/gallery/big-img/1.jpg" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
										<li><a href="<?php echo base_url()?>assets/gallery-details.html"><i class="fa fa-link"></i></a></li>
									</ul>
								</div>
							</div>
						</div>	
					</div>	
					<!-- End Single Gallery -->
					<!-- Start Single Gallery -->
					<div class="col-lg-3 col-md-4 col-sm-6 col-12 gallery__item cat--1">
						<div class="gallery">
							<div class="gallery__thum<?php echo base_url()?>assets/b">
								<a href="#">
									<img src="<?php echo base_url()?>assets/images/gallery/gl-page-one/2.jpg" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="<?php echo base_url()?>assets/images/gallery/big-img/2.jpg" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
										<li><a href="<?php echo base_url()?>assets/gallery-details.html"><i class="fa fa-link"></i></a></li>
									</ul>
								</div>
							</div>
						</div>	
					</div>	
					<!-- End Single Gallery -->
					<!-- Start Single Gallery -->
					<div class="col-lg-3 col-md-4 col-sm-6 col-12 gallery__item cat--2">
						<div class="gallery">
							<div class="gallery__thumb">
								<a href="#">
									<img src="<?php echo base_url()?>assets/images/gallery/gl-page-one/3.jpg" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="<?php echo base_url()?>assets/images/gallery/big-img/3.jpg" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
										<li><a href="<?php echo base_url()?>assets/gallery-details.html"><i class="fa fa-link"></i></a></li>
									</ul>
								</div>
							</div>
						</div>	
					</div>	
					<!-- End Single Gallery -->
					<!-- Start Single Gallery -->
					<div class="col-lg-3 col-md-4 col-sm-6 col-12 gallery__item cat--3">
						<div class="gallery">
							<div class="gallery__thumb">
								<a href="<?php echo base_url()?>assets/#">
									<img src="<?php echo base_url()?>assets/images/gallery/gl-page-one/4.jpg" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="<?php echo base_url()?>assets/images/gallery/big-img/4.jpg" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
										<li><a href="<?php echo base_url()?>assets/gallery-details.html"><i class="fa fa-link"></i></a></li>
									</ul>
								</div>
							</div>
						</div>	
					</div>	
					<!-- End Single Gallery -->
					<!-- Start Single Gallery -->
					<div class="col-lg-6 col-md-4 col-sm-6 col-12 gallery__item cat--1">
						<div class="gallery">
							<div class="gallery__thumb">
								<a href="<?php echo base_url()?>assets/#">
									<img src="<?php echo base_url()?>assets/images/gallery/gl-page-one/5.jpg" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="<?php echo base_url()?>assets/images/gallery/big-img/5.jpg" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
										<li><a href="<?php echo base_url()?>assets/gallery-details.html"><i class="fa fa-link"></i></a></li>
									</ul>
								</div>
							</div>
						</div>	
					</div>	
					<!-- End Single Gallery -->
					<!-- Start Single Gallery -->
					<div class="col-lg-3 col-md-4 col-sm-6 col-12 gallery__item cat--1">
						<div class="gallery">
							<div class="gallery__thumb">
								<a href="#">
									<img src="<?php echo base_url()?>assets/images/gallery/gl-page-one/6.jpg" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="images/gallery/big-img/6.jpg" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
										<li><a href="<?php echo base_url()?>assets/gallery-details.html"><i class="fa fa-link"></i></a></li>
									</ul>
								</div>
							</div>
						</div>	
					</div>	
					<!-- End Single Gallery -->
					<!-- Start Single Gallery -->
					<div class="col-lg-3 col-md-4 col-sm-6 col-12 gallery__item cat--2">
						<div class="gallery">
							<div class="gallery__thumb">
								<a href="#">
									<img src="<?php echo base_url()?>assets/images/gallery/gl-page-one/7.jpg" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="<?php echo base_url()?>assets/images/gallery/big-img/7.jpg" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
										<li><a href="<?php echo base_url()?>assets/gallery-details.html"><i class="fa fa-link"></i></a></li>
									</ul>
								</div>
							</div>
						</div>	
					</div>	
					<!-- End Single Gallery -->
					<!-- Start Single Gallery -->
					<div class="col-lg-3 col-md-4 col-sm-6 col-12 gallery__item cat--3">
						<div class="gallery">
							<div class="gallery__thumb">
								<a href="<?php echo base_url()?>assets/#">
									<img src="<?php echo base_url()?>assets/images/gallery/gl-page-one/8.jpg" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="<?php echo base_url()?>assets/images/gallery/big-img/8.jpg" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
										<li><a href="<?php echo base_url()?>assets/gallery-details.html"><i class="fa fa-link"></i></a></li>
									</ul>
								</div>
							</div>
						</div>	
					</div>	
					<!-- End Single Gallery -->
					<!-- Start Single Gallery -->
					<div class="col-lg-3 col-md-4 col-sm-6 col-12 gallery__item">
						<div class="gallery">
							<div class="gallery__thumb">
								<a href="#">
									<img src="<?php echo base_url()?>assets/images/gallery/gl-page-one/9.jpg" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="<?php echo base_url()?>assets/images/gallery/big-img/9.jpg" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
										<li><a href="<?php echo base_url()?>assets/gallery-details.html"><i class="fa fa-link"></i></a></li>
									</ul>
								</div>
							</div>
						</div>	
					</div>	
					<!-- End Single Gallery -->
					<!-- Start Single Gallery -->
					<div class="col-lg-3 col-md-4 col-sm-6 col-12 gallery__item cat--3">
						<div class="gallery">
							<div class="gallery__thumb">
								<a href="#">
									<img src="<?php echo base_url()?>assets/images/gallery/gl-page-one/10.jpg" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="<?php echo base_url()?>assets/images/gallery/big-img/10.jpg" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
										<li><a href="<?php echo base_url()?>assets/gallery-details.html"><i class="fa fa-link"></i></a></li>
									</ul>
								</div>
							</div>
						</div>	
					</div>	
					<!-- End Single Gallery -->
					<!-- Start Single Gallery -->
					<div class="col-lg-3 col-md-4 col-sm-6 col-12 gallery__item">
						<div class="gallery">
							<div class="gallery__thumb">
								<a href="#">
									<img src="<?php echo base_url()?>assets/images/gallery/gl-page-one/11.jpg" alt="gallery images">
								</a>
							</div>
							<div class="gallery__hover__inner">
								<div class="gallery__hover__action">
									<ul class="gallery__zoom">
										<li><a href="images/gallery/big-img/11.jpg" data-lightbox="grportimg" data-title="My caption"><i class="fa fa-search"></i></a></li>
										<li><a href="<?php echo base_url()?>assets/gallery-details.html"><i class="fa fa-link"></i></a></li>
									</ul>
								</div>
							</div>
						</div>	
					</div>	
					<!-- End Single Gallery -->
				</div>	
			</div>
		</div>
		<!-- End Our Gallery Area -->
		<!-- Start Subscribe Area -->
		
		</section>
		<!-- End Subscribe Area -->
		<!-- Footer Area -->
			<div class="copyright">
				<div class="container">
					<div class="row align-items-center copyright__wrapper">
						<div class="col-lg-6 col-md-6 col-sm-12">
							<div class="coppy__right__inner">
								<p>Copyright <i class="fa fa-copyright"></i> 2018 <a href="https://freethemescloud.com/" target="_blank" >Free Themes Cloud.</a> All rights reserved. </p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
        <!-- Register Form -->
        <div class="accountbox-wrapper">
            <div class="accountbox">
                <div class="accountbox__inner">
                	<h4>continue to register</h4>
                    <div class="accountbox__login">
                        <form action="#">
                            <div class="single-input">
                                <input  type="text" placeholder="User name">
                            </div>
                            <div class="single-input">
                                <input type="email" placeholder="E-mail">
                            </div>
                            <div class="single-input">
                                <input type="text" placeholder="Phone">
                            </div>
                            <div class="single-input">
                                <input type="password" placeholder="Password">
                            </div>
                            <div class="single-input">
                                <input type="password" placeholder="Confirm password">
                            </div>
                            <div class="single-input text-center">
                                <button type="submit" class="sign__btn">Sign Up Now</button>
                            </div>
                            <div class="accountbox-login__others text-center">
                                <h6>or register with</h6>
                                <ul class="dacre__social__link d-flex justify-content-center">
                                    <li class="facebook"><a target="_blank" href="https://www.facebook.com/"><span class="ti-facebook"></span></a></li>
                                    <li class="twitter"><a target="_blank" href="https://twitter.com/"><span class="ti-twitter"></span></a></li>
                                    <li class="pinterest"><a target="_blank" href="#"><span class="ti-google"></span></a></li>
                                </ul>
                            </div>
                        </form>
                    </div>
                    <span class="accountbox-close-button"><i class="zmdi zmdi-close"></i></span>
                </div>
                <h3>Have an account ? Login Fast</h3>
            </div>
        </div><!-- //Register Form -->

        <!-- Login Form -->
        <div class="login-wrapper">
            <div class="accountbox">
                <div class="accountbox__inner">
                	<h4>Login to Continue</h4>
                    <div class="accountbox__login">
                        <form action="#">
                            <div class="single-input">
                                <input type="email" placeholder="E-mail">
                            </div>
                            <div class="single-input">
                                <input type="password" placeholder="Password">
                            </div>
                            <div class="single-input text-center">
                                <button type="submit" class="sign__btn">SUBMIT</button>
                            </div>
                            <div class="accountbox-login__others text-center">
                                <ul class="dacre__social__link d-flex justify-content-center">
                                    <li class="facebook"><a target="_blank" href="https://www.facebook.com/"><span class="ti-facebook"></span></a></li>
                                    <li class="twitter"><a target="_blank" href="https://twitter.com/"><span class="ti-twitter"></span></a></li>
                                    <li class="pinterest"><a target="_blank" href="#"><span class="ti-google"></span></a></li>
                                </ul>
                            </div>
                        </form>
                    </div>
                    <span class="accountbox-close-button"><i class="zmdi zmdi-close"></i></span>
                </div>
                <h3>Have an account ? Login Fast</h3>
            </div>
        </div><!-- //Login Form -->

	</div><!-- //Main wrapper -->

	<!-- JS Files -->
	<script src="<?php echo base_url()?>assets/js/vendor/jquery-3.2.1.min.js"></script>
	<script src="<?php echo base_url()?>assets/js/popper.min.js"></script>
	<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url()?>assets/js/plugins.js"></script>
	<script src="<?php echo base_url()?>assets/js/active.js"></script>
</body>
</html>



