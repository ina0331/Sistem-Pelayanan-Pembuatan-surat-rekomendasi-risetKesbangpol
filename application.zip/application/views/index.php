<!doctype html>
<html class="no-js" lang="zxx">
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Bakesbangpol Kab.Bekasi</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Favicons -->
  <link rel="shortcut icon" href="images/logo/Bekasi.jpg">


<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <script language='JavaScript'>

    
var txt=" Bakesbangpol Kab.Bekasi | ";
var speed=250;
var refresh=null;
function action() { document.title=txt;
txt=txt.substring(1,txt.length)+txt.charAt(0);
refresh=setTimeout("action()",speed);}action();
</script>


  <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
  <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">


  <link href='<?php echo base_url() ?>assets/images/Bekasi.jpg' rel='shortcut icon'>
  <link rel="shortcut icon" href="<?php echo base_url() ?>assets/images/logo/bsi.jpg">
  <link rel="apple-touch-icon" href="images/halima.png">
  <!-- Google font (font-family: 'Lobster', Open+Sans;) -->
  <link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Lobster+Two:400,400i,700,700i" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet">

  <!-- Stylesheets -->
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/plugins.css">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/style.css">

  <!-- Cusom css -->
   <link rel="stylesheet" href="<?php echo base_url()?>assets/css/custom.css">

  <!-- Modernizer js -->
  <script src="<?php echo base_url()?>assets/js/vendor/modernizr-3.5.0.min.js"></script>
</head>
<body>
  <!--[if lte IE 9]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->

  <!-- Add your site or application content here -->
  
  <!-- <div class="fakeloader"></div> -->

  <!-- Main wrapper -->
  <div class="wrapper" id="wrapper">
    <!-- Header -->
    <header id="header" class="jnr__header header--one clearfix">
      <!-- Start Header Top Area -->
          
      </div>
      <!-- End Header Top Area -->
      <!-- Start Mainmenu Area -->
      <div class="mainmenu__wrapper bg__cat--1 poss-relative header_top_line sticky__header">
        <div cl  ass="container">
          <div class="row d-none d-lg-flex">
            <div class="col-sm-4 col-md-6 col-lg-2 order-1 order-lg-1">
              <div class="logo">
                <a href="<?php echo base_url()?>assets/index.html">
                  <img src="<?php echo base_url()?>assets/images/logo/Bekasi.jpg" alt="logo images">
                </a>
              </div>
            </div>
            <div class="col-sm-4 col-md-2 col-lg-9 order-3 order-lg-2">
              <div class="mainmenu__wrap">
                <nav class="mainmenu__nav">
                                    <ul class="mainmenu">
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/index">Home</a></li>
                                        <li class="drop"><a href="#">Pendaftaran</a>
                                            <ul class="dropdown__menu">
                                                <li><a href="<?php echo base_url()?>kesbang/upload">Penelitian</a></li>
                                              </ul>
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/tentang">Tentang</a></li>
                                        <li class="drop"><a href="<?php echo base_url()?>kesbang/gallery">Gallery</a></li>
                                        <li><a href="<?php echo base_url()?>kesbang/kontak">Kontak</a></li>
                                         <?php if($id_user = $this->session->userdata('id_user')) { ?>
            <?php $data_user = $this->m_user->get_data2('user',$id_user)->row_array(); echo $data_user['nama_lengkap'];?>
           

            <?php echo anchor('kesbang/logout', ' &nbsp Logout');?></li>

        <?php } else { ?>
            <?php echo anchor('kesbang/login_user', 'Login');?></li>
        <?php } ?> 
                                    </ul>
                                </nav>
              </div>
            </div>
            </div>
          </div>
          <!-- Mobile Menu -->
                    <div class="mobile-menu d-block d-lg-none">
                      <div class="logo">
                        <a href="<?php echo base_url()?>assets/index.html"><img src="<?php echo base_url()?>assets/images/logo/halima.png" alt="logo"></a>
                      </div>
                    </div>
                    <!-- Mobile Menu -->
        </div>
      </div>
      <!-- End Mainmenu Area -->
    </header>
    <!-- //Header -->
    <!-- Strat Slider Area -->
    <!-- Strat Slider Area -->
    <div class="slide__carosel owl-carousel owl-theme">
      <div class="slider__area bg-pngimage--11  d-flex fullscreen justify-content-start align-items-center">
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-lg-12 col-sm-12">
              <div class="slider__activation">
                <!-- Start Single Slide -->
                <div class="slide">
                  <div class="slide__inner">
                    <h1>Welcome To Bakesbangpol</h1>
                    <div class="slider__text">
                      <h2>Badan Kesatuan Bangsa Dan Politik</h2>
                      <h2>Kabupaten Bekasi</h2>
                    </div>
                    <div class="slider__btn">
                    </div>
                  </div>
                </div>
                <!-- End Single Slide -->
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="slider__area bg-pngimage--1  d-flex fullscreen justify-content-start align-items-center">
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-lg-12 col-sm-12">
              <div class="slider__activation">
                <!-- Start Single Slide -->
                <div class="slide">
                  <div class="slide__inner">
                    <h1>Welcom To Bakesbangpol</h1>
                    <div class="slider__text">
                      <h2>Badan Kesatuan Bangsa Dan Politik</h2>
                      <h2>KABUPATEN BEKASI</h2>
                    </div>
                    <div class="slider__btn">
                    </div>
                  </div>
                </div>
                <!-- End Single Slide -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- End Slider Area -->
    <!-- Start Our Gallery Area -->
    <section class="junior__gallery__area bg--white section-padding--lg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 col-sm-12 col-md-12">
            <div class="section__title text-center">
              <h2 class="title__line">Kegiatan Bakesbangpol</h2>
              <p></p>
            </p>
            </div>
          </div>
        </div>
        <div class="row galler__wrap mt--40">
          <!-- Start Single Gallery -->
          <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="gallery wow fadeInUp">
              <div class="gallery__thumb">
                <a href="<?php echo base_url()?>assets/#">
                  <img src="<?php echo base_url()?>assets/images/gallery/gallery-1/8.jpg" alt="gallery images">
                </a>
                
              </div>
              <div class="gallery__hover__inner">
                <div class="gallery__hover__action">
                  <h4 class="gallery__title"><a href="#"></a></h4>
                </div>
              </div>
            </div>  
          </div>  
          <!-- End Single Gallery -->
          <!-- Start Single Gallery -->
          <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="gallery wow fadeInUp">
              <div class="gallery__thumb">
                <a href="<?php echo base_url()?>assets/#">
                  <img src="<?php echo base_url()?>assets/images/gallery/gallery-1/10.jpg" alt="gallery images">
                </a>
            
              </div>
              <div class="gallery__hover__inner">
                <div class="gallery__hover__action">
                  <h4 class="gallery__title"><a href="#"></a></h4>
                </div>
              </div>
            </div>  
          </div>  
          <!-- End Single Gallery -->
          <!-- Start Single Gallery -->
          <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="gallery wow fadeInUp">
              <div class="gallery__thumb">
                <a href="<?php echo base_url()?>assets/#">
                  <img src="<?php echo base_url()?>assets/images/gallery/gallery-1/12.jpg" alt="gallery images">
                </a>
              </div>
              <div class="gallery__hover__inner">
                <div class="gallery__hover__action">
                  <h4 class="gallery__title"><a href="#"></a></h4>
                </div>
              </div>
            </div>  
          </div>  
          <!-- End Single Gallery -->
          <!-- Start Single Gallery -->
          <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="gallery wow fadeInUp">
              <div class="gallery__thumb">
                <a href="#">
                  <img src="<?php echo base_url()?>assets/images/gallery/gallery-1/14.jpg" alt="gallery images">
                </a>
              </div>
              <div class="gallery__hover__inner">
                <div class="gallery__hover__action">
                  <h4 class="gallery__title"><a href="#"></a></h4>
                </div>
              </div>
            </div>  
          </div>  
          <!-- End Single Gallery -->
          <!-- Start Single Gallery -->
          <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="gallery wow fadeInUp">
              <div class="gallery__thumb">
                <a href="#">
                  <img src="<?php echo base_url()?>assets/images/gallery/gallery-1/16.jpg" alt="gallery images">
                </a>
                <a href="#">
              </div>
              <div class="gallery__hover__inner">
                <div class="gallery__hover__action">
                  <h4 class="gallery__title"><a href="#"></a></h4>
                </div>
              </div>
            </div>  
          </div>  
          <!-- End Single Gallery -->
          <!-- Start Single Gallery -->
          <div class="col-lg-4 col-md-6 col-sm-6 col-12">
            <div class="gallery wow fadeInUp">
              <div class="gallery__thumb">
                <a href="#">
                  <img src="<?php echo base_url()?>assets/images/gallery/gallery-1/7.jpg" alt="gallery images">
                </a>
              </div>
              <div class="gallery__hover__inner">
                <div class="gallery__hover__action">
                  <h4 class="gallery__title"><a href="#"></a></h4>
                </div>
              </div>
            </div>  
          </div>  
          <!-- End Single Gallery -->
          
              
    </section>
    <!-- End Our Gallery Area -->
    <!-- Start Blog Area -->
    <section class="jnr__blog_area section-padding--lg bg-image--3">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 col-sm-12 col-md-12">
            <div class="section__title text-center white--title">
              <h2 class="title__line">Kabar Berita</h2>
              <p>Kabar Berita Seputar Bakesbangpol</p>
            </div>
          </div>
        </div>
        <div class="row blog__wrapper mt--40">
          <!-- Start Single Blog -->
          <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInLeft">
            <article class="blog">
              <div class="blog__date">
                <span></span>
              </div>
              <div class="blog__thumb">
                  <img src="<?php echo base_url()?>assets/images/blog/md-img/24.jpg" alt="blog images">
                </a>
              </div>
              <div class="blog__inner">
                <h4><a href="<?php echo base_url()?>assets/blog-details.html">Peningkatan Forum Kewaspadaan Dini Masyarakat</a></h4>
                <p>Diselenggarakan untuk meningkatkan kwaspadaan terhadap masyarkata.</p>
                <ul class="blog__meta d-flex flex-wrap flex-md-nowrap flex-lg-nowrap justify-content-between">
                </ul>
              </div>
            </article>
          </div>
          <!-- End Single Blog -->
          <!-- Start Single Blog -->
          <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
            <article class="blog">
              <div class="blog__date">
                <span></span>
              </div>
              <div class="blog__thumb">
                  <img src="<?php echo base_url()?>assets/images/blog/md-img/25.jpg" alt="blog images">
                </a>
              </div>
              <div class="blog__inner">
                <h4><a href="<?php echo base_url()?>assets/blog-details.html">Penguatan Forum Kerukunan Umat Beragama</a></h4>
                <p>diselenggarakan untuk memeperkuan hubuangan umat beragama</p>
                <ul class="blog__meta d-flex flex-wrap flex-md-nowrap flex-lg-nowrap justify-content-between">
                </ul>
              </div>
            </article>
          </div>
          <!-- End Single Blog -->
          <!-- Start Single Blog -->
          <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInRight">
            <article class="blog">
              <div class="blog__date">
                <span></span>
              </div>
              <div class="blog__thumb">
                  <img src="<?php echo base_url()?>assets/images/blog/md-img/26.jpg" alt="blog images">
                </a>
              </div>
              <div class="blog__inner">
                <h4><a href="blog-details.html"></a></h4>
                <p></p>
                <ul class="blog__meta d-flex flex-wrap flex-md-nowrap flex-lg-nowrap justify-content-between">
                </ul>
              </div>
            </article>
          </div>
          <!-- End Single Blog -->
        </div>
      </div>
    </section>
    <!-- End Blog Area -->
      
          </div>
        </div>
        <div class="ft__bottom__images--1 wow flipInX" data-wow-delay="0.6s">
          <img src="<?php echo base_url()?>assets/images/banner/mid-img/ft.png" alt="footer images">
        </div>
        <div class="ft__bottom__images--2 wow fadeInRight" data-wow-delay="0.6s">
          <img src="<?php echo base_url()?>assets/images/banner/mid-img/ft-2.png" alt="footer images">
        </div>
      </div>
      <!-- .Start Footer Contact Area -->
      <!-- .End Footer Contact Area -->
      <div class="copyright  bg--theme">
        <div class="container">
          <div class="row align-items-center copyright__wrapper justify-content-center">
            <div class="col-lg-12 col-sm-12 col-md-12">
              <div class="coppy__right__inner text-center">
                <p>Copyright <i class="fa fa-copyright"></i> 2019 <a href="https://freethemescloud.com/" target="_blank" >Kesbangpol.</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- //Footer Area -->
        <!-- Login Form -->
        <div class="login-wrapper">
            <div class="accountbox">
                <div class="accountbox__inner">
                  <h4>Login to Continue</h4>
                    <div class="accountbox__login">
                        <form action="#">
                            <div class="single-input">
                                <input type="email" placeholder="E-mail">
                            </div>
                            <div class="single-input">
                                <input type="password" placeholder="Password">
                            </div>
                            <div class="single-input text-center">
                                <button type="submit" class="sign__btn">SUBMIT</button>
                            </div>
                            <div class="accountbox-login__others text-center">
                                <ul class="dacre__social__link d-flex justify-content-center">
                                    <li class="facebook"><a target="_blank" href="<?php echo base_url()?>assets/https://www.facebook.com/"><span class="ti-facebook"></span></a></li>
                                </ul>
                            </div>
                        </form>
                    </div>
                    <span class="accountbox-close-button"><i class="zmdi zmdi-close"></i></span>
                </div>
                <h3>Sudah Punya Akun? Masuk</h3>
            </div>
        </div><!-- //Login Form -->

  </div><!-- //Main wrapper -->

  <!-- JS Files -->
  <script src="<?php echo base_url()?>assets/js/vendor/jquery-3.2.1.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/plugins.js"></script>
  <script src="<?php echo base_url()?>assets/js/active.js"></script>
</body>
</html>
