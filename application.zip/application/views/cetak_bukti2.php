<!DOCTYPE html>
<html>
<head>
 <title></title>
</head>
<body>
 <style type="text/css">
 .table-data{
   width: 100%;
   border-collapse: collapse;
  }

  .table-data tr th,
  .table-data tr td{
   border:1px solid black;
   font-size: 10pt;
  }
 </style>

 <?php 
	// echo print_r($siswa);
		foreach ($peneliti as $e) {
	?>
	&nbsp;&nbsp;<tr><th>&nbsp;&nbsp;Nama Admin</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->nama_lengkap; ?></th></tr>

	&nbsp;&nbsp;<tr><th>&nbsp;&nbsp;No.Telepon</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->no_telp; ?></th></tr>
	&nbsp;&nbsp;<tr><th>&nbsp;&nbsp;Id peneliti</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->id_peneliti; ?></th></tr>
	&nbsp;&nbsp;<tr><th>&nbsp;&nbsp;Alamat</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->alamat; ?></th></tr>
	<?php } ?>
	 </tbody>
</table> 

<script type="text/javascript">
 window.print();
</script>

</body>
</html>
